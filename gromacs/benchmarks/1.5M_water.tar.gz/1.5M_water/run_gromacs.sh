#!/bin/bash

LOG="gromacs_log_`date +%Y-%m-%d.%H:%M:%S`.log"
echo `date` > "$LOG"

#SET_NUMBER_OF_RANKS
RANKS=4
echo "RANKS=$RANKS" >> "$LOG"
#SET_RANKS_PER_HOST

PPN=4
echo "PPN=$PPN" >> "$LOG"

#SET_HOSTFILE
HOSTS="hosts.txt"
echo "HOSTS" >> "$LOG"
cat $HOSTS >> "$LOG"

#SET_EXE
EXE="gmx_mpi mdrun"
echo "EXE=$EXE" >> "$LOG"

#OMP THREADS
THREADS=1
echo "THREADS=$THREADS" >> "$LOG"

#OPTIMISATIONS
OPTS="-v"
echo "OPTS=$OPTS" >> "$LOG"


#INPUT FILE
INPUT="-deffnm md_0_1"
echo "INPUT=$INPUT" >> "$LOG"


echo "****************BENCHMARK_START****************" >> "$LOG"
mpirun -np $RANKS -ppn $PPN -hostfile $HOSTS $EXE -ntomp $THREADS $OPTS $INPUT 2>&1 | tee -a "$LOG"
